INSERT INTO CONTACT (FIRST_NAME,LAST_NAME) VALUES
  ('Jean-Claude','Goldman'),
  ('John','Volt'),
  ('Kevina','Blum');