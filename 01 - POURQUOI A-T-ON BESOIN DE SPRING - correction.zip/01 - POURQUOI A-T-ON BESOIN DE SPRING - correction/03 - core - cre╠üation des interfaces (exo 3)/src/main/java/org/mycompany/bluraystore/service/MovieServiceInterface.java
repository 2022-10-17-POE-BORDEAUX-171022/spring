package org.mycompany.bluraystore.service;

import org.mycompany.bluraystore.entity.Movie;

public interface MovieServiceInterface {

    public void registerMovie(Movie movie);
}
