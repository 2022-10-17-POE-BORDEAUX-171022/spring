package org.mycompany.bluraystore.repository;

import org.mycompany.bluraystore.entity.Movie;

import java.io.FileWriter;
import java.io.IOException;

// changement opéré
public class FileMovieRepository implements MovieRepositoryInterface {

    public void add(Movie movie) {

        try {
            FileWriter writer = new FileWriter("/Users/samihhabbani/Documents/spring_boot/movies.txt", true);
            writer.write(movie.getTitle() + ";" + movie.getGenre() + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}
