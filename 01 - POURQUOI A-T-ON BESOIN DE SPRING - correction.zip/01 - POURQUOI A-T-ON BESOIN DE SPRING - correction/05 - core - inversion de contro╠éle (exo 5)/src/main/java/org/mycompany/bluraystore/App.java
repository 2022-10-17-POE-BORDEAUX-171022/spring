package org.mycompany.bluraystore;

import org.mycompany.bluraystore.controller.MovieController;
import org.mycompany.bluraystore.repository.FileMovieRepository;
import org.mycompany.bluraystore.repository.MemoryMovieRepository;
import org.mycompany.bluraystore.repository.MovieRepositoryInterface;
import org.mycompany.bluraystore.service.DefaultMovieService;
import org.mycompany.bluraystore.service.MovieServiceInterface;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Quelle est la classe du controller?");
        String controllerName = scanner.nextLine();

        System.out.println("Quelle est la classe du service?");
        String serviceName = scanner.nextLine();

        System.out.println("Quelle est la classe du repository?");
        String repositoryName = scanner.nextLine();

        MovieController controller = null;
        MovieServiceInterface service = null;
        MovieRepositoryInterface repository = null;
        try {
            controller = (MovieController) Class.forName(controllerName).getDeclaredConstructor().newInstance();
            service = (DefaultMovieService) Class.forName(serviceName).getDeclaredConstructor().newInstance();
            repository = (FileMovieRepository) Class.forName(repositoryName).getDeclaredConstructor().newInstance();

        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        // org.mycompany.bluraystore.controller.MovieController
        // org.mycompany.bluraystore.service.DefaultMovieService
        // org.mycompany.bluraystore.repository.FileMovieRepository

        controller.setService(service);
        service.setRepository(repository);
        controller.addUsingConsole();

    }
}
