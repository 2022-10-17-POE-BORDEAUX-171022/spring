package org.mycompany.bluraystore.repository;

import org.mycompany.bluraystore.entity.Movie;

public interface MovieRepositoryInterface {

    // changement opéré
    public void add(Movie movie);

}
