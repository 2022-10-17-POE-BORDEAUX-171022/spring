package com.mycompany.invoice.invoiceweb.controller;


import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import com.mycompany.invoice.invoiceweb.form.InvoiceForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

//@Controller
//@RequestMapping("/invoice")
public class InvoiceControllerWeb1 {

    // je vais faire ici comme ci javais une interface graphique
    @Autowired
    private InvoiceServiceInterface service;

    @PostMapping("")
    public String createInvoice(@Valid @ModelAttribute InvoiceForm invoiceForm, BindingResult results) {

        if(results.hasErrors()) {
            return "invoice-create-form";
        }

        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice(invoiceForm.getCustomerInvoice());
        invoice.setNumber(invoiceForm.getNumber());

        // dépendance via le service
        // InvoiceServiceNewClient service = new InvoiceServiceNewClient();
        service.createInvoice(invoice);

        return "invoice-created";

    }

    /* @RequestMapping("/invoice-home")
    public String displayHome(HttpServletRequest request) {
        System.out.println("La méthode displayHome a été appelée");
        List<Invoice> listInvoices = service.getInvoiceList();
        System.out.println(listInvoices.toString());
        request.setAttribute("invoices", listInvoices);
        return "invoice-home";
    } **/

    /*@RequestMapping("/invoice-home")
    public @ModelAttribute("invoices") List<Invoice> displayHome() {
        return service.getInvoiceList();
    }*/

    @RequestMapping("/home")
    public String displayHome(Model model) { // toujours être en dernière position en argument
        model.addAttribute("invoices", service.getInvoiceList());
        return "invoice-home";
    }

    /* @RequestMapping("/{id}")
    public @ModelAttribute("invoice") Invoice displayInvoice(@PathVariable("id") String number) {
        System.out.println("La méthode displayInvoice a bien été appelée");
        return service.getInvoiceByNumber(number);
    } */

    /*@RequestMapping("/invoice-details/{id}")
    public ModelAndView displayInvoice(@PathVariable("id") String number) {
        System.out.println("La méthode displayInvoice a bien été appelée");
        ModelAndView mv = new ModelAndView("invoice-details");
        mv.addObject("invoice", service.getInvoiceByNumber(number));
        return mv;
    }*/

    // Notre controller REST s'en charge déjà
    /*@RequestMapping("/{id}")
    public ModelAndView displayInvoice(@PathVariable("id") String number) {
        System.out.println("La méthode displayInvoice a bien été appelée");
        ModelAndView mv = new ModelAndView("invoice-details");
        mv.addObject("invoice", service.getInvoiceByNumber(number));
        return mv;
    }*/

    @RequestMapping("/create-form")
    public String showCreateInvoice(@ModelAttribute InvoiceForm invoiceForm) {
        return "invoice-create-form";
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

}
