package com.mycompany.invoice.invoiceweb.api;


import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import com.mycompany.invoice.invoiceweb.form.InvoiceForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/invoice")
public class InvoiceRessource {

    // RequestBody
    // ResponseBody
    // RestController

    @Autowired
    private InvoiceServiceInterface service;

    @PostMapping
    public Invoice create(@RequestBody Invoice invoice) {
        return service.createInvoice(invoice);
    }

    @GetMapping
    public @ResponseBody
    List<Invoice> list() { // toujours être en dernière position en argument
        return service.getInvoiceList();
    }

    @RequestMapping("/{id}")
    public @ResponseBody Invoice displayInvoice(@PathVariable("id") String number) {
        System.out.println("La méthode displayInvoice a bien été appelée");
        return service.getInvoiceByNumber(number);
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

}
