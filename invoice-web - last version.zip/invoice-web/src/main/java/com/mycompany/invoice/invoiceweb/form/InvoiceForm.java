package com.mycompany.invoice.invoiceweb.form;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

// Jakarta Validation
public class InvoiceForm {

    // @Size(min = 0, max = 999, message = "Votre valeur doit être comprise entre 0 et 99")
    private String number;
    // @NotBlank(message = "customerInvoice ne peut pas être vide !")
    @NotBlank
    private String customerInvoice;

    private String orderNumber;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getCustomerInvoice() {
        return customerInvoice;
    }

    public void setCustomerInvoice(String customerInvoice) {
        this.customerInvoice = customerInvoice;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    @Override
    public String toString() {
        return "InvoiceForm{" +
                "number='" + number + '\'' +
                ", customerInvoice='" + customerInvoice + '\'' +
                ", orderNumber='" + orderNumber + '\'' +
                '}';
    }
}
