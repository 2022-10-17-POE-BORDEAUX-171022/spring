package com.mycompany.invoice.invoiceweb.controller;


import com.mycompany.invoice.core.controller.InvoiceControllerInterface;
import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import com.mycompany.invoice.invoiceweb.form.InvoiceForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("/invoice")
public class InvoiceControllerWeb {

    // je vais faire ici comme ci javais une interface graphique
    @Autowired
    private InvoiceServiceInterface service;

    @PostMapping("/create")
    public String createInvoice(@Valid @ModelAttribute InvoiceForm invoiceForm, BindingResult results) {
        if(results.hasErrors()) {
            return "invoice-create-form";
        }
        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice(invoiceForm.getCustomerInvoice());
        invoice.setNumber(invoiceForm.getNumber());
        invoice.setOrderNumber(invoiceForm.getOrderNumber());
        service.createInvoice(invoice);
        return "invoice-created";
    }

    @RequestMapping("/home")
    public String displayHome(Model model) { // toujours être en dernière position en argument
        model.addAttribute("invoices", service.getInvoiceList());
        return "invoice-home";
    }

    @RequestMapping("/create-form")
    public String showCreateInvoice(@ModelAttribute InvoiceForm invoiceForm) {
        return "invoice-create-form";
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

}
