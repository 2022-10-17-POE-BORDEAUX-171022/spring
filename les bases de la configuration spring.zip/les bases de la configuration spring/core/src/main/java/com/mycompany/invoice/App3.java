package com.mycompany.invoice;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import com.mycompany.invoice.repository.InvoiceRepositoryInterface;
import com.mycompany.invoice.service.InvoiceServiceInterface;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App3
{
    public static void main( String[] args )
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Quel type de controller?");
        String controllerName = scanner.nextLine();

        System.out.println("Quel type de service?");
        String serviceName = scanner.nextLine();

        System.out.println("Quel type de repository?");
        String repositoryName = scanner.nextLine();

        // stocker controller - service - repo
        InvoiceControllerInterface  controllerI = null;
        InvoiceServiceInterface serviceI = null;
        InvoiceRepositoryInterface  repositoryI = null;

        // On va instancier les classes dont on a besoin en fonction du nom des classes saisies
        // com.mycompany.invoice.controller.scanner.InvoiceControllerScanner
        // com.mycompany.invoice.service.prefix.InvoiceServicePrefix
        // com.mycompany.invoice.repository.database.InvoiceRepositoryDataBase

        try {
            controllerI = (InvoiceControllerInterface) Class.forName(controllerName
            ).getDeclaredConstructor().newInstance();

            serviceI = (InvoiceServiceInterface) Class.forName(serviceName
            ).getDeclaredConstructor().newInstance();

            repositoryI = (InvoiceRepositoryInterface) Class.forName(repositoryName
            ).getDeclaredConstructor().newInstance();

        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        controllerI.setService(serviceI);
        serviceI.setRepository(repositoryI);

        controllerI.createInvoice();

    }
}
