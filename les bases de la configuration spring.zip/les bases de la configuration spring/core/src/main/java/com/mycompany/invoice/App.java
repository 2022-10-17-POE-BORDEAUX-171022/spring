package com.mycompany.invoice;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import com.mycompany.invoice.repository.InvoiceRepositoryInterface;
import com.mycompany.invoice.service.InvoiceServiceInterface;
import com.mycompany.invoice.service.number.InvoiceServiceNumber;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
@Configuration
@ComponentScan(basePackages = {"com.mycompany.invoice.controller.web",
        "com.mycompany.invoice.service.prefix",
        "com.mycompany.invoice.repository.database"})
@PropertySource("classpath:application.properties")
// @ImportResource("classpath:applicationContext.xml")
public class App 
{
    public static void main( String[] args )
    {

        // je ne passe plus par le fichier xml mais par mon fichier de configuration
        ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);

        controller.createInvoice();

    }

    // j'ajoute au conteneur léger spring
    // le service InvoiceServiceNumber
    @Bean
    public InvoiceServiceInterface configureInvoiceServiceNumber() {
        return new InvoiceServiceNumber();
    }
}
