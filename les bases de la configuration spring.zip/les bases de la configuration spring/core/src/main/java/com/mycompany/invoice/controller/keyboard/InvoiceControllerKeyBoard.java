package com.mycompany.invoice.controller.keyboard;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import com.mycompany.invoice.entity.Invoice;
import com.mycompany.invoice.service.InvoiceServiceInterface;
import org.springframework.stereotype.Controller;

import java.util.Scanner;

@Controller
public class InvoiceControllerKeyBoard implements InvoiceControllerInterface {

    private InvoiceServiceInterface service;

    public void createInvoice() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Customer name : ");
        String customerName = scanner.nextLine();
        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice(customerName);
        // dépendance
        // InvoiceService service = new InvoiceService(); // couplage de classe
        service.createInvoice(invoice);

        // Que se passe-til si un client qui veut un formulaire et pas une ligne de commande
        // et qui veut préfixer ses factures par INV_

    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }
}
