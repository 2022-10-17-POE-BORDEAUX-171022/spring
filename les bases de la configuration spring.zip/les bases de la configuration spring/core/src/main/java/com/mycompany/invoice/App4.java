package com.mycompany.invoice;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App4
{
    public static void main( String[] args )
    {

        // Instancier un conteneur léger
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        // Spring va instancier tous les objets et les mettre en relation et conserver tout ça en mémoire
        // à partir de la variable context

        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);

        controller.createInvoice();

    }
}
