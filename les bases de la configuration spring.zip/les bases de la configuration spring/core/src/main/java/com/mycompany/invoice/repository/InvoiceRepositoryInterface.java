package com.mycompany.invoice.repository;

import com.mycompany.invoice.entity.Invoice;

public interface InvoiceRepositoryInterface {

    void createInvoice(Invoice invoice);
}
