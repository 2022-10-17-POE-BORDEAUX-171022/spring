package com.mycompany.invoice;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import com.mycompany.invoice.controller.keyboard.InvoiceControllerKeyBoard;
import com.mycompany.invoice.controller.scanner.InvoiceControllerScanner;
import com.mycompany.invoice.controller.web.InvoiceControllerWeb;
import com.mycompany.invoice.repository.database.InvoiceRepositoryDataBase;
import com.mycompany.invoice.repository.memory.InvoiceRepositoryInMemory;
import com.mycompany.invoice.repository.InvoiceRepositoryInterface;
import com.mycompany.invoice.service.InvoiceServiceInterface;
import com.mycompany.invoice.service.number.InvoiceServiceNumber;
import com.mycompany.invoice.service.prefix.InvoiceServicePrefix;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App2
{
    public static void main( String[] args )
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Quel type de controller? (keyboard, web, scanner)?");
        String controller = scanner.nextLine();

        System.out.println("Quel type de service? (number, prefix)?");
        String service = scanner.nextLine();

        System.out.println("Quel type de repository? (memory, bdd)?");
        String repository = scanner.nextLine();

        // stocker controller - service - repo
        InvoiceControllerInterface  controllerI = null;
        InvoiceServiceInterface serviceI = null;
        InvoiceRepositoryInterface  repositoryI = null;

        switch (controller) {
            case "keyboard" :
                controllerI = new InvoiceControllerKeyBoard();
                break;
            case "web" :
                controllerI = new InvoiceControllerWeb();
                break;
            case "scanner" :
                controllerI = new InvoiceControllerScanner();
                break;
        }

        switch (service) {
            case "number" :
                serviceI = new InvoiceServiceNumber();
                break;
            case "prefix" :
                serviceI = new InvoiceServicePrefix();
                break;
        }

        switch (repository) {
            case "memory" :
                repositoryI = new InvoiceRepositoryInMemory();
                break;
            case "bdd" :
                repositoryI = new InvoiceRepositoryDataBase();
                break;
        }

        controllerI.setService(serviceI);
        serviceI.setRepository(repositoryI);

        controllerI.createInvoice();

    }
}
