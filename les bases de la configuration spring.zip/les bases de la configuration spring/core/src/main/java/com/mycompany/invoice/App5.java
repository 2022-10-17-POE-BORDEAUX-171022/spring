package com.mycompany.invoice;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App5
{
    public static void main( String[] args )
    {

        // je ne passe plus par le fichier xml mais par mon fichier de configuration
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class, AppConfigPropertySource.class);
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);

        controller.createInvoice();

    }
}
