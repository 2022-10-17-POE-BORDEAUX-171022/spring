package com.mycompany.invoice;

import com.mycompany.invoice.controller.keyboard.InvoiceControllerKeyBoard;
import com.mycompany.invoice.controller.scanner.InvoiceControllerScanner;
import com.mycompany.invoice.controller.web.InvoiceControllerWeb;
import com.mycompany.invoice.repository.database.InvoiceRepositoryDataBase;
import com.mycompany.invoice.repository.memory.InvoiceRepositoryInMemory;
import com.mycompany.invoice.service.number.InvoiceServiceNumber;
import com.mycompany.invoice.service.prefix.InvoiceServicePrefix;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App1
{
    public static void main( String[] args )
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Dans quelle configuration êtes-vous?");
        int config = scanner.nextInt();

        if(config == 1) {
            InvoiceControllerKeyBoard controller = new InvoiceControllerKeyBoard();
            InvoiceServiceNumber service = new InvoiceServiceNumber();
            controller.setService(service); // Injection de dépendance du service dans le controller

            InvoiceRepositoryInMemory repository = new InvoiceRepositoryInMemory();
            service.setRepository(repository); // Injection de dépendance du répo dans le service

            controller.createInvoice();
        } else if(config == 2) {
            InvoiceControllerWeb controller = new InvoiceControllerWeb();
            InvoiceServicePrefix service = new InvoiceServicePrefix();
            controller.setService(service); // Injection de dépendance

            InvoiceRepositoryDataBase repository = new InvoiceRepositoryDataBase();
            service.setRepository(repository); // Injection de dépendance du répo dans le service

            controller.createInvoice();
        } else {
            InvoiceControllerScanner controller = new InvoiceControllerScanner();
            InvoiceServiceNumber service = new InvoiceServiceNumber();
            controller.setService(service); // Injection de dépendance du service dans le controller

            InvoiceRepositoryInMemory repository = new InvoiceRepositoryInMemory();
            service.setRepository(repository); // Injection de dépendance du répo dans le service

            controller.createInvoice();
        }
    }
}
