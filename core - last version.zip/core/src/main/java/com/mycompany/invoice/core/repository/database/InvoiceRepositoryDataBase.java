package com.mycompany.invoice.core.repository.database;

import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.repository.InvoiceRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Repository
public class InvoiceRepositoryDataBase implements InvoiceRepositoryInterface {

    // simulation de la BDD
    private static List<Invoice> invoices = new ArrayList<>();

    // JdbcTemplate va effectuer les requêtes
    // sans qu'on ai plus de config à faire
    // il va exploiter la datasource
    // récupérer une conexion
    // gérer les différentes erreurs
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Invoice createInvoice(Invoice invoice) {

        // invoices.add(invoice);
        System.out.println("Invoice added with number " + invoice.getNumber() + " for " + invoice.getCustomerInvoice());

        KeyHolder kh = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO INVOICE (CUSTOMER_NAME, ORDER_NUMBER) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, invoice.getCustomerInvoice());
            stmt.setString(2, invoice.getOrderNumber());

            return stmt;

        }, kh);

        invoice.setNumber(kh.getKey().toString());

        return invoice;

    }

    @Override
    public List<Invoice> list() {

        /*Invoice invoice1 = new Invoice();
        invoice1.setCustomerInvoice("Sam");
        invoice1.setNumber("1");

        Invoice invoice2 = new Invoice();
        invoice2.setCustomerInvoice("Jean");
        invoice2.setNumber("2");

        return List.of(invoice1, invoice2);*/
        // Dans la lambda ce qu'on utilise c'est un rowMapper
        // et on retourne pour chaque set de mon resultSet un objet de type Invoice dans lequel on initialise les valeurs des colonnes
        return jdbcTemplate.query("SELECT INVOICE_NUMBER, CUSTOMER_NAME FROM INVOICE",
        (set, rownum) -> new Invoice(String.valueOf(set.getLong("INVOICE_NUMBER")), set.getString("CUSTOMER_NAME")));


    }

    @Override
    public Invoice getById(String number) {

        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice("Sam");
        invoice.setNumber(number);

        return invoice;
    }

}
