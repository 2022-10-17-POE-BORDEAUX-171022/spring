package com.mycompany.invoice.core.controller;

import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;

public interface InvoiceControllerInterface {

    public String createInvoice(Invoice invoice);
    public void setService(InvoiceServiceInterface service);

}
