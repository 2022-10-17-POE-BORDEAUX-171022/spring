package com.mycompany.invoice.core.controller.keyboard;

import com.mycompany.invoice.core.controller.InvoiceControllerInterface;
import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;

import java.util.Scanner;

//@Controller
public class InvoiceControllerKeyBoard implements InvoiceControllerInterface {

    private InvoiceServiceInterface service;

    public String createInvoice(Invoice invoice) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Customer name : ");
        String customerName = scanner.nextLine();
        invoice = new Invoice();
        invoice.setCustomerInvoice(customerName);
        // dépendance
        // InvoiceService service = new InvoiceService(); // couplage de classe
        service.createInvoice(invoice);

        // Que se passe-til si un client qui veut un formulaire et pas une ligne de commande
        // et qui veut préfixer ses factures par INV_

        return "";

    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }
}
