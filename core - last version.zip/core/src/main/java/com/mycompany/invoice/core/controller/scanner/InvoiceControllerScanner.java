package com.mycompany.invoice.core.controller.scanner;

import com.mycompany.invoice.core.controller.InvoiceControllerInterface;
import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;

// @Controller
public class InvoiceControllerScanner implements InvoiceControllerInterface {

    private InvoiceServiceInterface service;

    public String createInvoice(Invoice invoice) {

        System.out.println("Je bipe avec ma douchette pour générer ma facture");
        invoice = new Invoice();
        invoice.setCustomerInvoice("SFR");

        // dépendance via le service
        // InvoiceServiceNewClient service = new InvoiceServiceNewClient();
        service.createInvoice(invoice);

        return "";

    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }
}
