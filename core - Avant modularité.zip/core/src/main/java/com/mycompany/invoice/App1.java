package com.mycompany.invoice;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Hello world!
 *
 */

// InvoiceControllerWeb
// InvoiceServicePrefix
// InvoiceRepositoryInMemory

@Configuration
@ComponentScan(basePackages = {"com.mycompany.invoice"})
// @ImportResource("classpath:applicationContext.xml")
public class App1
{
    public static void main( String[] args )
    {

        // je ne passe plus par le fichier xml mais par mon fichier de configuration
        ApplicationContext context = new AnnotationConfigApplicationContext(App1.class);
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);
        controller.createInvoice();

    }

}
