package com.mycompany.invoice.repository;

import com.mycompany.invoice.entity.Invoice;

import java.util.List;

public interface InvoiceRepositoryInterface {

    void createInvoice(Invoice invoice);
    List<Invoice> list();
}
