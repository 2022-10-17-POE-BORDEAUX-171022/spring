package com.mycompany.invoice;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

/**
 * Hello world!
 *
 */
// springboot va regarder à la racine de notre classpath si on a fichier application.properties
@SpringBootApplication
public class App
{
    public static void main( String[] args )
    {

        // maintenant l'application est pilotée par SpringBoot
        ApplicationContext context = SpringApplication.run(App.class);
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);
        controller.createInvoice();

    }

}
