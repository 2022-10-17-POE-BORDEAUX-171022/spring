package com.mycompany.invoice.controller.web;

import com.mycompany.invoice.controller.InvoiceControllerInterface;
import com.mycompany.invoice.entity.Invoice;
import com.mycompany.invoice.service.InvoiceServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class InvoiceControllerWeb implements InvoiceControllerInterface {

    // je vais faire ici comme ci javais une interface graphique
    @Autowired
    private InvoiceServiceInterface service;

    public void createInvoice() {

        String customerName = "My new customer";
        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice(customerName);

        // dépendance via le service
        // InvoiceServiceNewClient service = new InvoiceServiceNewClient();
        service.createInvoice(invoice);

    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

}
