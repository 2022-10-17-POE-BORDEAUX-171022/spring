package com.mycompany.invoice.service;

import com.mycompany.invoice.entity.Invoice;
import com.mycompany.invoice.repository.InvoiceRepositoryInterface;

public class InvoiceServicePrefix implements InvoiceServiceInterface {

    private static long lastNumber = 0L;

    // dépendance vers le repo
    // private InvoiceRepository repository = new InvoiceRepository();
    private InvoiceRepositoryInterface repository;

    public void createInvoice(Invoice invoice) {
        invoice.setNumber("INV_" + String.valueOf(++lastNumber)); // incrémente de 1 le numéro de facture
        repository.createInvoice(invoice);
    }

    public InvoiceRepositoryInterface getRepository() {
        return repository;
    }

    public void setRepository(InvoiceRepositoryInterface repository) {
        this.repository = repository;
    }
}
