package com.mycompany.invoice.controller;

import com.mycompany.invoice.entity.Invoice;
import com.mycompany.invoice.service.InvoiceServiceInterface;

public class InvoiceControllerScanner implements InvoiceControllerInterface{

    private InvoiceServiceInterface service;

    public void createInvoice() {

        System.out.println("Je bipe avec ma douchette pour générer ma facture");
        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice("SFR");

        // dépendance via le service
        // InvoiceServiceNewClient service = new InvoiceServiceNewClient();
        service.createInvoice(invoice);

    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }
}
