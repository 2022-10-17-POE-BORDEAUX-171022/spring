package com.mycompany.invoice.repository;

import com.mycompany.invoice.entity.Invoice;

import java.util.ArrayList;
import java.util.List;

public class InvoiceRepositoryDataBase implements InvoiceRepositoryInterface {

    // simulation de la BDD
    private static List<Invoice> invoices = new ArrayList<>();

    public void createInvoice(Invoice invoice) {

        /**
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");

            PreparedStatement stmt=con.prepareStatement("insert into Invoices values(?,?)");
            stmt.setInt(1,101);//1 specifies the first parameter in the query
            stmt.setString(2,"Ratan");

            int i=stmt.executeUpdate();
            System.out.println(i+" records inserted");

            con.close();

        }catch(Exception e){ System.out.println(e);}

         **/


    }

}
