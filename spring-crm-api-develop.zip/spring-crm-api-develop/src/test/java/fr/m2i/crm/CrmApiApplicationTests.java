package fr.m2i.crm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
