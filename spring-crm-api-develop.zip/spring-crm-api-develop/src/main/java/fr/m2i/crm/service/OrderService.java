package fr.m2i.crm.service;

import java.util.List;

import fr.m2i.crm.model.Order;

public interface OrderService {
	
	/**
	 * Get all orders
	 * @return
	 */
	public List<Order> getAll();
	
	/**
	 * Get order by id
	 * @param id the id
	 * @return
	 */
	public Order getById(Integer id);
	
	/**
	 * Create order
	 * @param order the order to create
	 * @return the created order
	 */
	public Order createOrder(Order order);
	
	/**
	 * Delete order
	 * @param id the order id
	 */
	public void deleteOrder(Integer id);
	
	/**
	 * Update order
	 * @param order the order
	 * @return the updated order
	 */
	public Order updateOrder(Order order);
	
	/**
	 * Update order status
	 * @param orderId the order Id
	 * @param status the new status
	 */
	public void patchOrderStatus(Integer orderId, String status);

}
