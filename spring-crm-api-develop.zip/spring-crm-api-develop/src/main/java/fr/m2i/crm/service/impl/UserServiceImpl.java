package fr.m2i.crm.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import fr.m2i.crm.exception.UnknownResourceException;
import fr.m2i.crm.model.User;
import fr.m2i.crm.repository.UserRepository;
import fr.m2i.crm.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<User> getAll() {
		return userRepository.findAll(Sort.by("username").ascending());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public User getById(Integer id) {
		return userRepository.findById(id).orElseThrow(UnknownResourceException::new);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public User createUser(User user) {
		return userRepository.save(user);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public User getUserByUsernameAndPassword(String username, String password) {
		return userRepository.findByUsernameAndPassword(username, password);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deleteUser(User user) {
		User userToDelete = userRepository.findById(user.getId()).orElseThrow(UnknownResourceException::new);
		userRepository.delete(userToDelete);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public User update(User user) {
		User userExistant = userRepository.findById(user.getId()).orElseThrow(UnknownResourceException::new);
		userExistant.setGrants(user.getGrants());
		userExistant.setMail(user.getMail());
		userExistant.setPassword(user.getPassword());
		userExistant.setUsername(user.getUsername());
		return userRepository.save(user);
	}

}
