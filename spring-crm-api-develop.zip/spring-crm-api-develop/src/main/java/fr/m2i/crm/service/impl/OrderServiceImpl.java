package fr.m2i.crm.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import fr.m2i.crm.exception.UnknownResourceException;
import fr.m2i.crm.model.Order;
import fr.m2i.crm.repository.OrderRepository;
import fr.m2i.crm.service.OrderService;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
	
	Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);

	@Autowired
	private OrderRepository orderRepository;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Order> getAll() {
		return orderRepository.findAll(Sort.by("label").ascending());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Order getById(Integer id) {
		return orderRepository.findById(id).orElseThrow(UnknownResourceException::new);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Order createOrder(Order order) {
		log.debug("attempting to create order...");
		return orderRepository.save(order);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deleteOrder(Integer id) {
		Order order = orderRepository.findById(id).orElseThrow(UnknownResourceException::new);
		log.debug("attempting to delete order [{}]", id);
		orderRepository.delete(order);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Order updateOrder(Order order) {
		log.debug("attempting to update order {}...", order.getId());
		Order existingOrder = orderRepository.findById(order.getId()).orElseThrow(UnknownResourceException::new);
		existingOrder.setLabel(order.getLabel());
		existingOrder.setNumberOfDays(order.getNumberOfDays());
		existingOrder.setNotes(order.getNotes());
		existingOrder.setStatus(order.getStatus());
		existingOrder.setTva(order.getTva());
		existingOrder.setAdrEt(order.getAdrEt());
		existingOrder.setType(order.getType());
		return orderRepository.save(existingOrder);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void patchOrderStatus(Integer orderId, String status) {
		log.debug("attempting to patch order {} with status {}...", orderId, status);
		Order existingOrder = orderRepository.findById(orderId).orElseThrow(UnknownResourceException::new);
		existingOrder.setStatus(status);
		orderRepository.save(existingOrder);
	}
	
	/**
	 * Determine if an order can be deleted (status ?)
	 * @param order the order
	 * @return true if the order can be deleted, false otherwise
	 */
	private boolean allowedToDeleteOrder(Order order) {
		return !(null != order.getStatus() && !"En cours".equals(order.getStatus()));
	}

}
