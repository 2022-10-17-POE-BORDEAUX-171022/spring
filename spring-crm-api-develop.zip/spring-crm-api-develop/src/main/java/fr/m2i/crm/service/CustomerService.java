package fr.m2i.crm.service;

import java.util.List;

import fr.m2i.crm.model.Customer;

public interface CustomerService {
	
	/**
	 * Get all customers
	 * @return the list of customers
	 */
	public List<Customer> getAll();
	
	/**
	 * Get a customer by id 
	 * @param id the customer id
	 * @return the customer
	 */
	public Customer getById(Integer id);
	
	/**
	 * Create customer
	 * @param customer the customer to create
	 * @return the created customer
	 */
	public Customer createCustomer(Customer customer);
	
	/**
	 * Delete customer
	 * @param id the customer id
	 */
	public void deleteCustomer(Integer id);
	
	/**
	 * Update customer
	 * @param customer the customer to update
	 * @return the updated customer
	 */
	public Customer updateCustomer(Customer customer);
	
	public void patchCustomerStatus(Integer customerId, boolean active);

}
