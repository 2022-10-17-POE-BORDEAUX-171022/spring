package fr.m2i.crm.api.v1;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import fr.m2i.crm.api.v1.dto.OrderDto;
import fr.m2i.crm.exception.UnknownResourceException;
import fr.m2i.crm.mapper.OrderMapper;
import fr.m2i.crm.model.Order;
import fr.m2i.crm.service.OrderService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1/orders")
@CrossOrigin(value = { "*" }, allowedHeaders = { "*" })
public class OrderApi {

	Logger log = LoggerFactory.getLogger(OrderApi.class);

	private OrderService orderService;

	private OrderMapper orderMapper;

	public OrderApi(OrderService orderService, OrderMapper orderMapper) {
		this.orderService = orderService;
		this.orderMapper = orderMapper;
	}

	@GetMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Returns the list of all orders", nickname = "Get all orders", response = Order.class)
	public ResponseEntity<List<OrderDto>> getAll() {
		return ResponseEntity
				.ok(orderService.getAll().stream().map(orderMapper::mapOrderToOrderDto).collect(Collectors.toList()));
	}

	@GetMapping(value = "/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Return an order", nickname = "Get an order by Id", response = OrderDto.class)
	public ResponseEntity<OrderDto> getById(@PathVariable final Integer id) {
		try {
			return ResponseEntity.ok(orderMapper.mapOrderToOrderDto(orderService.getById(id)));
		} catch (UnknownResourceException ure) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Order Not Found");
		}
	}

	@ApiOperation(value = "Create order", nickname = "Create order", code = 201)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Created") })
	@PostMapping(produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<OrderDto> createOrder(@RequestBody final OrderDto orderDto) {
		log.debug("Attempting to create order with label {}", orderDto.getLabel());
		OrderDto newOrder = orderMapper
				.mapOrderToOrderDto(orderService.createOrder(orderMapper.mapOrderDtoToOrder(orderDto)));
		return ResponseEntity.created(URI.create("/v1/orders/" + newOrder.getId())).body(newOrder);
	}

	@ApiOperation(value = "Delete order", nickname = "Delete order", code = 204)
	@ApiResponses(value = { @ApiResponse(code = 204, message = "No Content") })
	@DeleteMapping(path = "{id}")
	public ResponseEntity<Void> deleteOrder(@PathVariable final Integer id) {
		try {
			log.debug("Preparing to delete order with id [{}]", id);
			orderService.deleteOrder(id);
			return ResponseEntity.noContent().build();
		} catch (UnknownResourceException ure) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Order Not Found");
		}
	}

	@ApiOperation(value = "Update order", nickname = "Update order", code = 204)
	@ApiResponses(value = { @ApiResponse(code = 204, message = "No Content") })
	@PutMapping(path = "{id}", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<Void> updateOrder(@PathVariable final Integer id, @RequestBody OrderDto orderDto) {
		try {
			log.debug("Updating order {}", id);
			orderDto.setId(id);
			orderService.updateOrder(orderMapper.mapOrderDtoToOrder(orderDto));
			log.debug("Successfully updated order {}", id);
			return ResponseEntity.noContent().build();
		} catch (UnknownResourceException ure) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Order Not Found");
		}
	}

}
