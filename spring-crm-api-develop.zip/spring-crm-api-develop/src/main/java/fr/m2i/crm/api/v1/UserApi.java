package fr.m2i.crm.api.v1;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import fr.m2i.crm.api.v1.dto.UserDto;
import fr.m2i.crm.exception.UnknownResourceException;
import fr.m2i.crm.mapper.UserMapper;
import fr.m2i.crm.model.User;
import fr.m2i.crm.service.UserService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1/users")
@CrossOrigin(value = {"*"}, allowedHeaders = {"*"})
public class UserApi {
	
	private UserService userService;
	
	private UserMapper userMapper;
	
	public UserApi(UserService userService, UserMapper userMapper) {
		this.userService = userService;
		this.userMapper = userMapper;
	}

	@GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE})
    @ApiOperation(value = "Returns the list of all users", nickname = "Get all users", response = UserDto.class)
    public ResponseEntity<List<UserDto>> getAll() {
        return ResponseEntity.ok(userService.getAll().stream().map(userMapper::mapUserToUserDto)
				.collect(Collectors.toList()));
    }
	
	@GetMapping(value = "/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<User> getUserById(@PathVariable Integer id) {
		return ResponseEntity.ok(userService.getById(id));
	}
	
	@GetMapping(value = "/login", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ApiOperation(value = "Returns a user", nickname = "Get a user", response = UserDto.class)
    public ResponseEntity<UserDto> getByUsernameAndPassword(@RequestParam String username, @RequestParam String password) {
		try {
			UserDto userDto = userMapper.mapUserToUserDto(userService.getUserByUsernameAndPassword(username, password));
			userDto.setToken("fakeToken");
			return ResponseEntity.ok(userDto);
		} catch (UnknownResourceException ure) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer Not Found");
		}
	}
	
	@PostMapping(produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Create user", nickname = "Create user", code = 201)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Created") })
	public ResponseEntity<UserDto> createUser(@RequestBody UserDto userDto) {
		System.out.println("user : " + userDto.getUsername());
		UserDto newUser = userMapper.mapUserToUserDto(userService.createUser(userMapper.mapUserDtoToUser(userDto)));
		return ResponseEntity.created(URI.create("/v1/users/" + newUser.getId())).body(newUser);
	}
	
	@DeleteMapping("/{id}")
	@ApiOperation(value = "Delete a user", nickname = "Delete user", code = 204)
	public ResponseEntity<Void> deleteUser(@PathVariable int id) {
		try {
			userService.deleteUser(userService.getById(id));
			return ResponseEntity.noContent().build();
		} catch (UnknownResourceException e) {
			return ResponseEntity.notFound().build();
		}
	}
	
	@PutMapping(value = "/{id}", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Update a user", nickname = "Update user", code = 204)
	public ResponseEntity<Void> updateUser(@RequestBody UserDto userDto, @PathVariable Integer id) {
		try {
			userDto.setId(id);
			userService.update(userMapper.mapUserDtoToUser(userDto));
			return ResponseEntity.noContent().build();
		} catch (UnknownResourceException e) {
			return ResponseEntity.notFound().build();
		}
	}

}
