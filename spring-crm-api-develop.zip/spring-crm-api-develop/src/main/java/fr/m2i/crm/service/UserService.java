package fr.m2i.crm.service;

import java.util.List;

import fr.m2i.crm.model.User;

public interface UserService {
	
	/**
	 * Get all users
	 * @return the list of users
	 */
	public List<User> getAll();
	
	/**
	 * Get a user by id
	 * @param id the user id
	 * @return the user
	 */
	public User getById(Integer id);
	
	/**
	 * Create a user
	 * @param user the user to create
	 * @return the created user
	 */
	public User createUser(User user);
	
	/**
	 * Get a user by username and password
	 * @param username
	 * @param password
	 * @return
	 */
	public User getUserByUsernameAndPassword(String username, String password);

	/**
	 * Delete a user
	 * @param user the user to delete
	 */
	public void deleteUser(User user);
	
	/**
	 * Update a user
	 * @param user the user to update
	 * @return
	 */
	public User update(User user);
	
	
}
