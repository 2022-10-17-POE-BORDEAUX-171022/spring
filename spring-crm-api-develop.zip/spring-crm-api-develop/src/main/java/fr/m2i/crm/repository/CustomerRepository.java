package fr.m2i.crm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.m2i.crm.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
