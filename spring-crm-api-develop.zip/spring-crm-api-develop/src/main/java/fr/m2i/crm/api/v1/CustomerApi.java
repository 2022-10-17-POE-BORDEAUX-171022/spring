package fr.m2i.crm.api.v1;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import fr.m2i.crm.api.v1.dto.CustomerDto;
import fr.m2i.crm.exception.UnknownResourceException;
import fr.m2i.crm.mapper.CustomerMapper;
import fr.m2i.crm.service.CustomerService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1/customers")
@CrossOrigin(value = { "*" }, allowedHeaders = { "*" })
public class CustomerApi {

	Logger log = LoggerFactory.getLogger(CustomerApi.class);

	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private CustomerMapper customerMapper;

	@GetMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Returns the list of all customers", nickname = "Get all customers", response = CustomerDto.class)
	public ResponseEntity<List<CustomerDto>> getAll() {
		return ResponseEntity.ok(customerService.getAll().stream().map(customerMapper::mapCustomerToCustomerDto)
				.collect(Collectors.toList()));
	}

	@GetMapping(value = "/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Return a customer", nickname = "Get a customer by Id", response = CustomerDto.class)
	public ResponseEntity<CustomerDto> getById(@PathVariable final Integer id) {
		try {
			return ResponseEntity.ok(customerMapper.mapCustomerToCustomerDto(customerService.getById(id)));
		} catch (UnknownResourceException ure) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer Not Found");
			//return ResponseEntity.notFound().build();
		}
	}

	@ApiOperation(value = "Create customer", nickname = "Create customer", code = 201)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Created") })
	@PostMapping(produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<CustomerDto> createCustomer(@RequestBody final CustomerDto customerDto) {
		log.debug("Attempting to create customer with name {}", customerDto.getLastname());
		CustomerDto newcustomer = customerMapper.mapCustomerToCustomerDto(
				customerService.createCustomer(customerMapper.mapCustomerDtoToCustomer(customerDto)));
		return ResponseEntity.created(URI.create("/v1/customers/" + newcustomer.getId())).body(newcustomer);
		//return ResponseEntity.status(201).body(newcustomer);
	}

	@ApiOperation(value = "Delete customer", nickname = "Delete customer", code = 204)
	@ApiResponses(value = { @ApiResponse(code = 204, message = "No Content") })
	@DeleteMapping(path = "/{id}")
	public ResponseEntity<Void> deleteCustomer(@PathVariable final Integer id) {
		try {
			log.debug("Preparing to delete customer with id {}", id);
			customerService.deleteCustomer(id);
			return ResponseEntity.noContent().build();
		} catch (UnknownResourceException ure) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer Not Found");
		}
	}

	@ApiOperation(value = "Update customer", nickname = "Update customer", code = 204)
	@ApiResponses(value = { @ApiResponse(code = 204, message = "No Content") })
	@PutMapping(path = "/{id}", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<Void> updateCustomer(@PathVariable final Integer id, @RequestBody CustomerDto customerDto) {
		try {
			log.debug("Updating customer {}", id);
			customerDto.setId(id);
			customerService.updateCustomer(customerMapper.mapCustomerDtoToCustomer(customerDto));
			log.debug("Successfully updated customer {}", id);
			return ResponseEntity.noContent().build();
		} catch (UnknownResourceException ure) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer Not Found");
		}
	}

	@ApiOperation(value = "Update customer status", nickname = "Update customer status", code = 204)
	@ApiResponses(value = { @ApiResponse(code = 204, message = "No Content") })
	@PatchMapping(path = "/{id}", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<Void> patchCustomerStatus(@PathVariable final Integer id,
			@RequestBody CustomerDto customerDto) {
		try {
			log.debug("Patching customer {} status", id);
			customerDto.setId(id);
			customerService.patchCustomerStatus(id, customerDto.getActive());
			log.debug("Successfully patched customer {}", id);
			return ResponseEntity.noContent().build();
		} catch (UnknownResourceException ure) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer Not Found");
		}
	}

}
