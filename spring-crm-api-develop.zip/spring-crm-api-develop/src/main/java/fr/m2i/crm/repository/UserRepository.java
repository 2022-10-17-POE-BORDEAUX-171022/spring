package fr.m2i.crm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.m2i.crm.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {
	
	User findByUsername(String username);

	/**
	 * Get a user by username and password
	 * @param username the username
	 * @param password the password
	 * @return the user
	 */
	User findByUsernameAndPassword(String username, String password);
}
