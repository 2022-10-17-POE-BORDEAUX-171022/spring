package fr.m2i.crm.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.springframework.stereotype.Component;

import fr.m2i.crm.api.v1.dto.UserDto;
import fr.m2i.crm.model.User;

@Component
@Mapper(componentModel = "spring", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface UserMapper {
	
	@Mapping(target = "password", ignore = true)
    UserDto mapUserToUserDto(User user);
	
    User mapUserDtoToUser(UserDto userDto);

}
