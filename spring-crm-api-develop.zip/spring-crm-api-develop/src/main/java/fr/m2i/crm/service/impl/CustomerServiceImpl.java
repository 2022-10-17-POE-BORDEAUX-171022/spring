package fr.m2i.crm.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import fr.m2i.crm.exception.UnknownResourceException;
import fr.m2i.crm.model.Customer;
import fr.m2i.crm.repository.CustomerRepository;
import fr.m2i.crm.service.CustomerService;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	
	Logger log = LoggerFactory.getLogger(CustomerServiceImpl.class);

	@Autowired
	private CustomerRepository customerRepository;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Customer> getAll() {
		return customerRepository.findAll(Sort.by("lastname").ascending());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customer getById(Integer id) {
		return customerRepository.findById(id).orElseThrow(UnknownResourceException::new);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customer createCustomer(Customer customer) {
		log.debug("attempting to create customer...");
		return customerRepository.save(customer);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deleteCustomer(Integer id) {
		Customer customer = customerRepository.findById(id).orElseThrow(UnknownResourceException::new);
		log.debug("attempting to delete customer {}", id);
		if (allowedToDeleteCustomer(customer)) {
			customerRepository.delete(customer);
		}
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Customer updateCustomer(Customer customer) {
		log.debug("attempting to update customer {}...", customer.getId());
		Customer clientExistant = customerRepository.findById(customer.getId()).orElseThrow(UnknownResourceException::new);
		clientExistant.setLastname(customer.getLastname());
		clientExistant.setFirstname(customer.getFirstname());
		clientExistant.setMail(customer.getMail());
		clientExistant.setCompany(customer.getCompany());
		clientExistant.setPhone(customer.getPhone());
		clientExistant.setMobile(customer.getMobile());
		clientExistant.setNotes(customer.getNotes());
		clientExistant.setActive(customer.isActive());
		return customerRepository.save(clientExistant);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void patchCustomerStatus(Integer customerId, boolean active) {
		log.debug("attempting to patch customer {} with active = {}...", customerId, active);
		Customer existingCustomer = customerRepository.findById(customerId).orElseThrow(UnknownResourceException::new);
		existingCustomer.setActive(active);
		customerRepository.save(existingCustomer);
	}
	
	/**
	 * Determine if a customer can be deleted (no order)
	 * @param customer the customer
	 * @return true if the customer can be deleted, false otherwise
	 */
	private boolean allowedToDeleteCustomer(Customer customer) {
		return !(null != customer.getOrders() && !customer.getOrders().isEmpty());
		/*if ( null != client.getOrders() && !client.getOrders().isEmpty()) {
			return false;
		}
		return true;*/
	}

}
