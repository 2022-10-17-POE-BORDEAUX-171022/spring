package fr.m2i.crm.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.springframework.stereotype.Component;

import fr.m2i.crm.api.v1.dto.OrderDto;
import fr.m2i.crm.model.Order;

@Component
@Mapper(componentModel = "spring", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, uses = {
        CustomerMapper.class})
public interface OrderMapper {
	
	@Mapping(source = "customer.id", target = "customerId")
	OrderDto mapOrderToOrderDto(Order order);
	
	@Mapping(source = "customerId", target = "customer.id")
	Order mapOrderDtoToOrder(OrderDto orderDto);

}
