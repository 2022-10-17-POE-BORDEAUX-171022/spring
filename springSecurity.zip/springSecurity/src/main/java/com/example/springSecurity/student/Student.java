package com.example.springSecurity.student;

public class Student {

    private final Integer student_id;
    private final String studentName;

    public Student(Integer student_id, String studentName) {
        this.student_id = student_id;
        this.studentName = studentName;
    }

    public Integer getStudent_id() {
        return student_id;
    }

    public String getStudentName() {
        return studentName;
    }
}
